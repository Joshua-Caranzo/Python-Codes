from flask import Flask,render_template,request,redirect,url_for,flash,session, jsonify
from flask import current_app as app
from dbhelper import *

app = Flask(__name__)
app.secret_key = "!@#$%"
	
imagefolder = "static/img"
app.config["UPLOAD_FOLDER"] = imagefolder
	
	
@app.route("/")
def register()->None:
    emails:list = getemails()
    return render_template("register.html",title="register",registered_emails=emails)
    
	
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
    
def getemails() -> list:
    users = getall('users')
    email_list = [user['email'] for user in users]
    return email_list


@app.route("/saveuser", methods=['POST'])
def saveuser():
    if request.method == 'POST':
        file = request.files.get('webcam')
        email = request.args.get('email')
        password = request.args.get('password')

        if len(email) > 0 and len(password) > 0:
            users = getall('users')
            if any(user['email'] == email for user in users):
                flash('Email already exists in the database. Please use a different email.', 'error')
            else:
                ok = addrecord('users', email=email, password=password)
                users = getall('users')
                user = users[-1]
                filename = imagefolder + "/" + str(user['id']) + ".jpg"

                if file:
                    file.save(filename)

                if ok:
                    flash('User data and image saved successfully!', 'success')
                else:
                    flash('Failed to save user data.', 'error')
        else:
            flash('Invalid email or password.', 'error')
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'message': 'Invalid request method'})

        
@app.route("/login", methods=['POST', 'GET'])
def login() -> None:
    email = ''
    password = ''
    if request.method == "POST":
        email = request.form['email']
        password = request.form['password']
        # set a static user validation
        user: list = getuser('users', email=email, password=password)
        if len(user) > 0:
            session['name'] = user[0]['id']
            flash("Login successful", 'success')
            return render_template("login.html", title="login", email=email, password=password)
        else:
            flash("Invalid User")
            return redirect(url_for("login"))
    return render_template("login.html", title="login", email=email, password=password)

@app.route("/clear")
def clear():
  if "email" in session:
    session.pop("email")
    session.clear()
    session["clear_image"] = True
    flash("Cleared")
    return redirect(url_for("register"))
  else:
    return redirect(url_for("register"))
    
@app.route("/loginclear")
def clears():
  if "email" in session:
    session.pop("email")
    session.clear()
    session["clear_image"] = True
    flash("Cleared")
    return redirect(url_for("login"))
  else:
    return redirect(url_for("login"))


@app.route("/main")
def main()->None:
	return render_template("register.html",title="my flask app")
	
if __name__=="__main__":
	app.run(host="0.0.0.0",debug=True)
	
	
	